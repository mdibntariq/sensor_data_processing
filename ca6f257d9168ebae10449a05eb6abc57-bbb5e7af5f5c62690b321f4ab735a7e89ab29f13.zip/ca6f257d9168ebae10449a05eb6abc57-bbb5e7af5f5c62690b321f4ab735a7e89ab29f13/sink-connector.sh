$curl -X POST -H “Content-Type: application/json” — data '{
  "name": "connector-name",
  "config": {
    "connector.class":"io.confluent.connect.hdfs.HdfsSinkConnector",
    "tasks.max":,
    "topics":"ad_server_event_A,ad_server_event_B,ad_server_event_C…",
    "hdfs.url":,
    "flush.size":,
    "rotate.interval.ms":"1000000",
    "logs.dir":,
    "topics.dir":,
	  "hive.database":,
	  "hive.integration":"true",
	  "hive.metastore.uris":,
 	  "schema.compatibility":"BACKWARD",
 	  "format.class":"io.confluent.connect.hdfs.parquet.ParquetFormat",
 	  "partitioner.class":"io.confluent.connect.hdfs.partitioner.FieldPartitioner",
 	  "partition.field.name":"day",
  }
}' http://kafka-connect-cluster/connectors;